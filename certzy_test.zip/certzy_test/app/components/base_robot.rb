module Robotech
  module Component
    class BaseRobot
    end
  end
end
