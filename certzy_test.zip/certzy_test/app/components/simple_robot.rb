require_relative "base_robot"

module Robotech
  module Component
    class SimpleRobot < BaseRobot
      ORIENTATION = ["north", "east", "south", "west"]

      def initialize(ruleset:)
        @ruleset = ruleset
        @current_position = nil
        @orientation_index = nil
      end

      def action(command)
        action, parameters = command
        return if (@current_position.nil? && action != "place")

        case action
        when "left"
          turn_left
        when "right"
          turn_right
        when "report"
          print_position
        when "move"
          move_robot
        when "place"
          place_robot(parameters)
        end
      rescue ArgumentError => e
        # Do nothing
      end

      private

      def turn_left
        @orientation_index = (@orientation_index - 1) % ORIENTATION.length
      end

      def turn_right
        @orientation_index = (@orientation_index + 1) % ORIENTATION.length
      end

      def move_robot
        next_position = position_on_move
        return unless @ruleset.valid_position?(next_position)
        @current_position = next_position
      end

      def position_on_move
        return if @current_position.nil? || @orientation_index.nil?
        next_position = @current_position.clone
        case @orientation_index
        when 0
          next_position[:y] += 1
        when 1
          next_position[:x] += 1
        when 2
          next_position[:y] -= 1
        when 3
          next_position[:x] -= 1
        end

        next_position
      end

      def place_robot(location)
        return unless @ruleset.valid_position?({ x: location[0].to_i, y: location[1].to_i })
        @orientation_index = ORIENTATION.index(location[2])
        @current_position = { x: location[0].to_i, y: location[1].to_i }
      end

      def print_position
        return if @current_position.nil?
        puts "#{@current_position[:x]},#{@current_position[:y]},#{ORIENTATION[@orientation_index].upcase}"
      end
    end
  end
end
